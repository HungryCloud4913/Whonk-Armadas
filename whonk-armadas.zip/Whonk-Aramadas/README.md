# Whonk Armadas:
## The whonk armadas are here to bring war to the galaxies.
## Stealing any sprites and/or content from this is not allowed and will bring us(The creators) great sadness.
### We are very dumb at the whonk headquarters so expect some of the dumbest amounts of content ever.
